<footer id="footer">
			
			<div class="section">
				
				<div class="container">
					
					<div class="row">
						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">About Us</h3>
								<p>This is my Small Database Management System mini project</p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-map-marker"></i>RayMond, Washington</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>1800 444 001</a></li>
									<li><a href="#"><i class="fa fa-envelope-o"></i>OurRayMond.com</a></li>
								</ul>
							</div>
						</div>
						<div class="col-md-6 text-center" style="margin-top:80px;">
							<ul class="footer-payments">
								<li><a href="#"><i class="fa fa-cc-visa" style="color:navy;"></i></a></li>
								<li><a href="#"><i class="fa fa-credit-card" style="color:blue;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-paypal" style="color:red;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-mastercard" style="color:yellow;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-discover" style="color: aqua;"></i></a></li>
								<li><a href="#"><i class="fa fa-cc-amex" style="color: orange;"></i></a></li>
							</ul>
							<span class="copyright">
								
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Binil,Felbin,Asish</a>
							
							</span>
						</div>

						<div class="col-md-3 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Other<br>Categories</h3>
								<ul class="footer-links">
									<li><a href="#"><u><b>MENS WEAR</b></u></a></li>
									<li><a href="#">-<b>&nbsp;Dhoti</b></a></li>
									<li><a href="#">-<b>&nbsp;Shorts</b></a></li>
									<li><a href="#">-<b>&nbsp;Suits</b></a></li>
									<li><a href="#">-<b>&nbsp;Blazers</b></a></li>
									<li><a href="#"><u><b>InnerWear</b></u></a></li>
									<li><a href="#">-<b>&nbsp;Brief</b></a></li>
									<li><a href="#">-<b>&nbsp;Vest</b></a></li>









								</ul>
							</div>
						</div>

						<div class="clearfix visible-xs"></div>

						
					</div>
					
				</div>
				
			</div>
			
                

		
			
		
		</footer>
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>
		<script src="js/actions.js"></script>
		<script src="js/sweetalert.min"></script>
		<script src="js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="js/script.js"></script>
		<script>var c = 0;
        function menu(){
          if(c % 2 == 0) {
            document.querySelector('.cont_drobpdown_menu').className = "cont_drobpdown_menu active";    
            document.querySelector('.cont_icon_trg').className = "cont_icon_trg active";    
            c++; 
              }else{
            document.querySelector('.cont_drobpdown_menu').className = "cont_drobpdown_menu disable";        
            document.querySelector('.cont_icon_trg').className = "cont_icon_trg disable";        
            c++;
              }
        }
           
		
</script>
    <script type="text/javascript">
		$('.block2-btn-addcart').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to cart !", "success");
			});
		});

		$('.block2-btn-addwishlist').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to wishlist !", "success");
			});
		});
	</script>
	
